import tkinter as tk
import pyodbc
import sys
import pandas as pd

def ObtenerBBDD():

    # Define la cadena de conexión a la base de datos principal para obtener la bbdd principal
    conn_str = (
        r"Driver={SQL Server};"
        r"Server=DESKTOP-KFESO7O\WINCC;"
        r"Database=master;"
        r"Trusted_Connection=yes;"
    )

    # Crea una conexión a la base de datos
    conn = pyodbc.connect(conn_str)

    # Crea un objeto cursor
    cursor = conn.cursor()

    # Ejecuta una consulta SQL
    cursor.execute('SELECT * FROM dbo.CAConfig')

    # Obtiene los resultados de la consulta
    ResultTxtLib = cursor.fetchall()

    # Nombre base de datos
    nombre_bbdd = ""

    # Imprime los resultados en la consola
    for _, db_name, _ in ResultTxtLib:
        nombre_bbdd = db_name[:-1] # Le quito la "R" del final del nombre de la BBDD

    # Cierra la conexión a la base de datos
    conn.close()

    if nombre_bbdd == "":
        print("No se ha podido obtener la base de datos del proyecto")
        sys.exit()
    return nombre_bbdd

def ListarArls(Filtro):
    
    output = list()

    nombre_bbdd = ObtenerBBDD()

    # Define la cadena de conexión a la base de datos del proyecto
    conn_str = (
        r"Driver={SQL Server};"
        r"Server=DESKTOP-KFESO7O\WINCC;"
        f"Database={nombre_bbdd};"
        r"Trusted_Connection=yes;"
    )

    # Crea una conexión a la base de datos
    conn = pyodbc.connect(conn_str)

    # Crea un objeto cursor
    cursor = conn.cursor()

    # Definir la consula SQL
    SQLQuery = r""
    SQLQuery += r"SELECT dbo.TXTTable.L1034 AS L1034_TB1, dbo.MSMsgs.NR, dbo.MSMsgs.PARAMS "
    SQLQuery += r"FROM dbo.MSMsgs "
    SQLQuery += r"JOIN dbo.TXTTable ON dbo.MSMsgs.TB1 = dbo.TXTTable.TEXTID "

    if Filtro != "":
        SQLQuery += f"WHERE dbo.TXTTable.L1034 LIKE '%{Filtro}%' "

    SQLQuery += r"ORDER BY dbo.MSMsgs.NR"

    # Ejecuta una consulta SQL para obtener tabla del text library
    cursor.execute(SQLQuery)

    # Obtiene los resultados de la consulta
    RspQuery = cursor.fetchall()

    # Cierra la conexión a la base de datos
    conn.close()

    for alarma in RspQuery:

        AlrTxt, AlrNr, AlrParam = alarma

        # Comproba si está habilitada la función de enviar (se comprueba el Bit 8 de "PARAMS")
        bit_position = 8
        HabEnvia = AlrParam & (1 << bit_position) != 0
        
        output.append([AlrTxt, HabEnvia, AlrNr])

    return output

def CambiarHab(AlrNr):

    NombreBBDD = ObtenerBBDD()

    # Define la cadena de conexión a la base de datos del proyecto
    ConnStr = (
        r"Driver={SQL Server};"
        r"Server=DESKTOP-KFESO7O\WINCC;"
        f"Database={NombreBBDD};"
        r"Trusted_Connection=yes;"
    )

    # Crea una conexión a la base de datos
    Conn = pyodbc.connect(ConnStr)

    # Crea un objeto cursor
    Cursor = Conn.cursor()

    # Definir la consula SQL
    SQLQuery = r""
    SQLQuery += r"UPDATE dbo.MSMsgs "
    SQLQuery += r"SET PARAMS = PARAMS ^ 256 "
    SQLQuery += f"WHERE NR = {AlrNr}"

    print(SQLQuery)

    # Ejecuta una consulta SQL para obtener tabla del text library
    Cursor.execute(SQLQuery)

    Cursor.commit()

    # Cierra la conexión a la base de datos
    Conn.close()

def CambiarArl(event):

    global TxtAlrs, HabsAlrs, IdsAlrs

    TxtAlrSel = TxtAlrsList.curselection()

    AlrNr = (IdsAlrs[TxtAlrSel[0]])
    
    CambiarHab(AlrNr)

    ActualizarListBox()

def ActualizarListBox():

    # Actualizar listbox
    global FiltroAlr

    scroll_position = TxtAlrsList.yview()[0]  # Obtener la posición de desplazamiento

    AlsAMostar = list()

    for TxtAlr, HabAlr, IdAlr in ListarArls(FiltroAlr):

        EstadoAlr = "No enviar"

        if HabAlr:
            EstadoAlr = "Enviar"

        AlsAMostar.append(f'{TxtAlr} - {EstadoAlr}')

    TxtAlrsList.delete(0, tk.END)
    TxtAlrsList.insert(0, *AlsAMostar)

    TxtAlrsList.yview_moveto(scroll_position)  # Aplicar la misma posición de desplazamiento


# Reset filtro
FiltroAlr = ""

Alarmas = ListarArls(FiltroAlr)

TxtAlrs = list(zip(*Alarmas))[0]
HabsAlrs = list(zip(*Alarmas))[1]
IdsAlrs = list(zip(*Alarmas))[2]

AlsAMostar = list()

for TxtAlr, HabAlr, IdAlr in ListarArls(FiltroAlr):

    EstadoAlr = "No enviar"

    if HabAlr:
        EstadoAlr = "Enviar"

    AlsAMostar.append(f'{TxtAlr} - {EstadoAlr}')

import tkinter as tk

ventana = tk.Tk()
ventana.geometry("400x600")
ventana.title("Configurar envio alarmas")
ventana.resizable(width=False, height=False)  # Bloquear redimensionamiento y maximización

# Fitro de alarmas (fusilado de Chat-GPT)--------------------------------------

# Función para obtener el valor del campo de entrada
def FiltrarAlarmas(*args):

    global FiltroAlr
    FiltroAlr = campo_var.get()

    ActualizarListBox()

# Crear una variable de control para el campo de entrada
campo_var = tk.StringVar()

# Asociar la variable de control al campo de entrada
campo = tk.Entry(ventana, textvariable=campo_var)
campo.pack()

# Registrar la función on_cambio para ejecutarse cada vez que la variable de control cambie
campo_var.trace("w", FiltrarAlarmas)
# ------------------------------------------------------------------------------

ScrollBar = tk.Scrollbar(ventana)
ScrollBar.pack(side=tk.RIGHT, fill=tk.Y)

# Crear lista de alarmas
TxtAlrsList = tk.Listbox(ventana, yscrollcommand=ScrollBar.set)
TxtAlrsList.pack(side=tk.LEFT, fill="both", padx=10, pady=50)
TxtAlrsList.configure(width=60)


TxtAlrsList.insert(0, *AlsAMostar)

# Binding double click with left mouse
# button with go function
TxtAlrsList.bind('<Double-1>', CambiarArl)

ventana.mainloop()
