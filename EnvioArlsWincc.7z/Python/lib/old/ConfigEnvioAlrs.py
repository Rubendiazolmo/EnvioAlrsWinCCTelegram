import tkinter as tk
import pyodbc
import sys
import pandas as pd

def ObtenerBBDD():

    # Define la cadena de conexión a la base de datos principal para obtener la bbdd principal
    conn_str = (
        r"Driver={SQL Server};"
        r"Server=DESKTOP-KFESO7O\WINCC;"
        r"Database=master;"
        r"Trusted_Connection=yes;"
    )

    # Crea una conexión a la base de datos
    conn = pyodbc.connect(conn_str)

    # Crea un objeto cursor
    cursor = conn.cursor()

    # Ejecuta una consulta SQL
    cursor.execute('SELECT * FROM dbo.CAConfig')

    # Obtiene los resultados de la consulta
    ResultTxtLib = cursor.fetchall()

    # Nombre base de datos
    nombre_bbdd = ""

    # Imprime los resultados en la consola
    for _, db_name, _ in ResultTxtLib:
        nombre_bbdd = db_name[:-1] # Le quito la "R" del final del nombre de la BBDD

    # Cierra la conexión a la base de datos
    conn.close()

    if nombre_bbdd == "":
        print("No se ha podido obtener la base de datos del proyecto")
        sys.exit()
    return nombre_bbdd

def ListarArls():
    
    output = list()

    nombre_bbdd = ObtenerBBDD()

    # Define la cadena de conexión a la base de datos del proyecto
    conn_str = (
        r"Driver={SQL Server};"
        r"Server=DESKTOP-KFESO7O\WINCC;"
        f"Database={nombre_bbdd};"
        r"Trusted_Connection=yes;"
    )

    # Crea una conexión a la base de datos
    conn = pyodbc.connect(conn_str)

    # Crea un objeto cursor
    cursor = conn.cursor()

    # Definir la consula SQL
    SQLQuery = r""
    SQLQuery += r"SELECT dbo.TXTTable.L1034 AS L1034_TB1, dbo.MSMsgs.NR, dbo.MSMsgs.PARAMS "
    SQLQuery += r"FROM dbo.MSMsgs "
    SQLQuery += r"JOIN dbo.TXTTable ON dbo.MSMsgs.TB1 = dbo.TXTTable.TEXTID "
    SQLQuery += r"ORDER BY dbo.MSMsgs.NR"

    # Ejecuta una consulta SQL para obtener tabla del text library
    cursor.execute(SQLQuery)

    # Obtiene los resultados de la consulta
    RspQuery = cursor.fetchall()

    # Cierra la conexión a la base de datos
    conn.close()

    for alarma in RspQuery:

        AlrTxt, AlrNr, AlrParam = alarma

        # Comproba si está habilitada la función de enviar (se comprueba el Bit 8 de "PARAMS")
        bit_position = 8
        HabEnvia = AlrParam & (1 << bit_position) != 0
        
        output.append([AlrTxt, HabEnvia, AlrNr])

    return output

def CambiarHab(AlrNr):

    nombre_bbdd = ObtenerBBDD()

    # Define la cadena de conexión a la base de datos del proyecto
    conn_str = (
        r"Driver={SQL Server};"
        r"Server=DESKTOP-KFESO7O\WINCC;"
        f"Database={nombre_bbdd};"
        r"Trusted_Connection=yes;"
    )

    # Crea una conexión a la base de datos
    conn = pyodbc.connect(conn_str)

    # Crea un objeto cursor
    cursor = conn.cursor()

    # Definir la consula SQL
    SQLQuery = r""
    SQLQuery += r"UPDATE dbo.MSMsgs "
    SQLQuery += r"SET PARAMS = PARAMS ^ 256 "
    SQLQuery += f"WHERE NR = {AlrNr}"

    print(SQLQuery)

    # Ejecuta una consulta SQL para obtener tabla del text library
    cursor.execute(SQLQuery)

    cursor.commit()

    # Cierra la conexión a la base de datos
    conn.close()


items = ListarArls()

# Constantes de paginación
ITEMS_PER_PAGE = 10
total_pages = (len(items) + ITEMS_PER_PAGE - 1) // ITEMS_PER_PAGE

# Variables para el control de páginas
current_page = 1

def prev_page():
    if current_page > 1:
        show_page(current_page - 1)

def next_page():
    if current_page < total_pages:
        show_page(current_page + 1)

# Funciones para la paginación
def show_page(page_number):
    global current_page
    current_page = page_number
    start_index = (page_number - 1) * ITEMS_PER_PAGE
    end_index = start_index + ITEMS_PER_PAGE
    page_items = items[start_index:end_index]
    update_checkbuttons(page_items)
    label_page_number.config(text=str(current_page))

def update_checkbuttons(page_items):
    for index, item in enumerate(page_items):
        name = item[0]
        enabled = item[1]
        checkbuttons[index].config(text=name)
        checkbuttons[index].variable.set(enabled)

def update_enabled(index):
    items_index = (current_page - 1) * ITEMS_PER_PAGE + index
    items[items_index][1] = not items[items_index][1]
    CambiarHab(items[items_index][2])

# Crear ventana principal
window = tk.Tk()

# Crear variables BooleanVar para las casillas de verificación
checkbuttons = []
for _ in range(ITEMS_PER_PAGE):
    var = tk.BooleanVar()
    checkbutton = tk.Checkbutton(window, variable=var)
    checkbuttons.append(checkbutton)
    checkbutton.variable = var

# Crear casillas de verificación para cada elemento
for index in range(ITEMS_PER_PAGE):
    row_index = index // 2
    column_index = index % 2

    name = items[index][0]
    checkbutton = checkbuttons[index]
    checkbutton.config(text=name, command=lambda i=index: update_enabled(i))
    checkbutton.grid(row=row_index, column=column_index, sticky="w")

# Crear botones de paginación
button_prev = tk.Button(window, text="Anterior", command=prev_page)
button_prev.grid(row=(ITEMS_PER_PAGE // 2), column=0, sticky="w")
button_next = tk.Button(window, text="Siguiente", command=next_page)
button_next.grid(row=(ITEMS_PER_PAGE // 2), column=1, sticky="e")

# Crear etiqueta para mostrar el número de página actual
label_page_number = tk.Label(window, text="1")
label_page_number.grid(row=(ITEMS_PER_PAGE // 2), column=1, sticky="w")

# Mostrar la primera página inicialmente
show_page(1)

# Iniciar el loop del GUI
window.mainloop()