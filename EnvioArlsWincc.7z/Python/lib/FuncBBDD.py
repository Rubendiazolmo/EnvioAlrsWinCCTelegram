import pyodbc
import sys
import pandas as pd

def ObtenerBBDD():

    # Define la cadena de conexión a la base de datos principal para obtener la bbdd principal
    conn_str = (
        r"Driver={SQL Server};"
        r"Server=DESKTOP-KFESO7O\WINCC;"
        r"Database=master;"
        r"Trusted_Connection=yes;"
    )

    # Crea una conexión a la base de datos
    conn = pyodbc.connect(conn_str)

    # Crea un objeto cursor
    cursor = conn.cursor()

    # Ejecuta una consulta SQL
    cursor.execute('SELECT * FROM dbo.CAConfig')

    # Obtiene los resultados de la consulta
    ResultTxtLib = cursor.fetchall()

    # Nombre base de datos
    nombre_bbdd = ""

    # Imprime los resultados en la consola
    for _, db_name, _ in ResultTxtLib:
        nombre_bbdd = db_name[:-1] # Le quito la "R" del final del nombre de la BBDD

    # Cierra la conexión a la base de datos
    conn.close()

    if nombre_bbdd == "":
        print("No se ha podido obtener la base de datos del proyecto")
        sys.exit()
    return nombre_bbdd

def ObtenerTxtAlr(AlarmaAEnviar):

    nombre_bbdd = ObtenerBBDD()

    # Define la cadena de conexión a la base de datos del proyecto
    conn_str = (
        r"Driver={SQL Server};"
        r"Server=DESKTOP-KFESO7O\WINCC;"
        f"Database={nombre_bbdd};"
        r"Trusted_Connection=yes;"
    )

    # Crea una conexión a la base de datos
    conn = pyodbc.connect(conn_str)

    # Crea un objeto cursor
    cursor = conn.cursor()

    # Definir la consula SQL
    SQLQuery =  r""
    SQLQuery += r"SELECT dbo.TXTTable.L1034 "
    SQLQuery += r"FROM dbo.MSMsgs "
    SQLQuery += r"JOIN dbo.TXTTable ON dbo.MSMsgs.TB1 = dbo.TXTTable.TEXTID "
    SQLQuery += f"WHERE dbo.MSMsgs.NR = {AlarmaAEnviar}"

    """
    Explicación (fusilada de ChatGPT):

    - La cláusula SELECT selecciona el campo L1034 de la tabla dbo.TXTTable, que contiene el texto de la alarma.
    - La cláusula FROM especifica las tablas que se van a usar en la consulta: dbo.MSMsgs y dbo.TXTTable.
    - La cláusula JOIN relaciona las dos tablas por medio del campo TB1 de dbo.MSMsgs y el campo TEXTID de dbo.TXTTable.
    - La cláusula WHERE filtra los resultados para que sólo se muestre el texto de la alarma que tenga el id especificado en dbo.MSMsgs.NR.
    """

    # Ejecuta una consulta SQL para obtener tabla del text library
    cursor.execute(SQLQuery)

    # Obtiene los resultados de la consulta
    RspQuery = cursor.fetchall()

    # Cierra la conexión a la base de datos
    conn.close()

    # Obtengo texto alarma de la respuesta de la query
    TxtAlr = (RspQuery[0][0])

    return (TxtAlr)

def ListarArls():
    
    nombre_bbdd = ObtenerBBDD()

    # Define la cadena de conexión a la base de datos del proyecto
    conn_str = (
        r"Driver={SQL Server};"
        r"Server=DESKTOP-KFESO7O\WINCC;"
        f"Database={nombre_bbdd};"
        r"Trusted_Connection=yes;"
    )

    # Crea una conexión a la base de datos
    conn = pyodbc.connect(conn_str)

    # Crea un objeto cursor
    cursor = conn.cursor()

    # Definir la consula SQL
    SQLQuery = r""
    SQLQuery += r"SELECT dbo.TXTTable.L1034 AS L1034_TB1, tb3.L1034 AS L1034_TB3, dbo.MSMsgs.NR "
    SQLQuery += r"FROM dbo.MSMsgs "
    SQLQuery += r"JOIN dbo.TXTTable ON dbo.MSMsgs.TB1 = dbo.TXTTable.TEXTID "
    SQLQuery += r"JOIN dbo.TXTTable tb3 ON dbo.MSMsgs.TB3 = tb3.TEXTID "
    SQLQuery += r"ORDER BY dbo.MSMsgs.NR"

    """
    Explicación (fusilada de ChatGPT):

    - La cláusula SELECT selecciona el campo L1034 de la tabla dbo.TXTTable, que contiene el texto de la alarma.
    - La cláusula FROM especifica las tablas que se van a usar en la consulta: dbo.MSMsgs y dbo.TXTTable.
    - La cláusula JOIN relaciona las dos tablas por medio del campo TB1 de dbo.MSMsgs y el campo TEXTID de dbo.TXTTable.
    - La cláusula WHERE filtra los resultados para que sólo se muestre el texto de la alarma que tenga el id especificado en dbo.MSMsgs.NR.
    """

    # Ejecuta una consulta SQL para obtener tabla del text library
    cursor.execute(SQLQuery)

    # Obtiene los resultados de la consulta
    RspQuery = cursor.fetchall()

    # Cierra la conexión a la base de datos
    conn.close()

    # Obtengo texto alarma de la respuesta de la query
    df = pd.DataFrame(RspQuery)

    print(df)