import pyodbc
import sys
import pandas as pd

def ObtenerBBDD():

    # Define la cadena de conexión a la base de datos principal para obtener la bbdd principal
    conn_str = (
        r"Driver={SQL Server};"
        r"Server=DESKTOP-KFESO7O\WINCC;"
        r"Database=master;"
        r"Trusted_Connection=yes;"
    )

    # Crea una conexión a la base de datos
    conn = pyodbc.connect(conn_str)

    # Crea un objeto cursor
    cursor = conn.cursor()

    # Ejecuta una consulta SQL
    cursor.execute('SELECT * FROM dbo.CAConfig')

    # Obtiene los resultados de la consulta
    ResultTxtLib = cursor.fetchall()

    # Nombre base de datos
    nombre_bbdd = ""

    # Imprime los resultados en la consola
    for _, db_name, _ in ResultTxtLib:
        nombre_bbdd = db_name[:-1] # Le quito la "R" del final del nombre de la BBDD

    # Cierra la conexión a la base de datos
    conn.close()

    if nombre_bbdd == "":
        print("No se ha podido obtener la base de datos del proyecto")
        sys.exit()
    return nombre_bbdd

def ListarArls():
    
    nombre_bbdd = ObtenerBBDD()

    # Define la cadena de conexión a la base de datos del proyecto
    conn_str = (
        r"Driver={SQL Server};"
        r"Server=DESKTOP-KFESO7O\WINCC;"
        f"Database={nombre_bbdd};"
        r"Trusted_Connection=yes;"
    )

    # Crea una conexión a la base de datos
    conn = pyodbc.connect(conn_str)

    # Crea un objeto cursor
    cursor = conn.cursor()

    # Definir la consula SQL
    SQLQuery = r""
    SQLQuery += r"SELECT dbo.TXTTable.L1034 AS L1034_TB1, dbo.MSMsgs.NR, dbo.MSMsgs.PARAMS "
    SQLQuery += r"FROM dbo.MSMsgs "
    SQLQuery += r"JOIN dbo.TXTTable ON dbo.MSMsgs.TB1 = dbo.TXTTable.TEXTID "
    SQLQuery += r"ORDER BY dbo.MSMsgs.NR"

    # Ejecuta una consulta SQL para obtener tabla del text library
    cursor.execute(SQLQuery)

    # Obtiene los resultados de la consulta
    RspQuery = cursor.fetchall()

    # Cierra la conexión a la base de datos
    conn.close()

    for alarma in RspQuery:

        AlrTxt, AlrNr, AlrParam = alarma

        # Comproba si está habilitada la función de enviar (se comprueba el Bit 8 de "PARAMS")
        bit_position = 8
        HabEnvia = AlrParam & (1 << bit_position) != 0
        
        print(AlrTxt, AlrNr, HabEnvia, sep=" - ")

ListarArls()