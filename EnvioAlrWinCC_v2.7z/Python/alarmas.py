import sys
import time
import subprocess
import json
from lib.FuncBBDD import ObtenerTxtAlr

PATH = "C:/Python/"

# Configuracion de lectura de alarmas

AlrAct         = sys.argv[1].replace("./Alrs/","") # Alarma activada, estructura pszMsgData de WinCC
AlrAct         = AlrAct.split("_")
AlrId          = int(AlrAct[0])
AlrStado       = int(AlrAct[1]) # 1 = Activada, 2 = Desactivada, 3 = Reconocida

# Configuracion de avisos por telegram

TOKEN_BOT      = "5010499917:AAFd05Y2PLe4IitbvheM-DebdNVbJOJ3pkk"
CHAT_ID        = "-1001738340790%20"
MENSAJE_ALARMA = ""

if AlrStado == 1:
    MENSAJE_ALARMA = ObtenerTxtAlr(AlrId) + " activada"
if AlrStado == 2:
    MENSAJE_ALARMA = ObtenerTxtAlr(AlrId) + " desactivada"

if MENSAJE_ALARMA != "":

    # Enviar mensaje y guardar respuesta de curl.
    rsp = subprocess.Popen(f'curl -d "text={MENSAJE_ALARMA}" -X POST https://api.telegram.org/bot{TOKEN_BOT}/sendMessage?chat_id={CHAT_ID}', stdout=subprocess.PIPE)
    stdout = json.load(rsp.stdout)
    
    ok = (stdout["ok"]) # Comprobar que el mensaja ha sido enviado
    
    #Si el mensaje no se ha enviado (por cualquier motivo a excepcion del cooldown de Telegram) escribimos en log.txt la respuesta de curl y salimos del script con codigo de respuesta 1 (error)
    if not ok:
        print("El mensaje no se ha enviado")
        codigo_error = int(stdout["error_code"]) # Obtener codigo de error
        
        # Si el error no viene del cooldown guardo en el registro el error.
        if codigo_error != 429:
            log = open("log.txt", "a")
            log.write(str(time.time())+": "+str(stdout)+"\n")
            log.close()
        sys.exit(1)
    

time.sleep(0.75)

