import sys
import time
import subprocess
import json
from lib.FuncBBDD import ObtenerAlr
from datetime import datetime

PATH = "C:/Python/"

# Configuracion de lectura de alarmas

AlrAct         = sys.argv[1].replace("./Alrs/","") # Alarma activada, estructura pszMsgData de WinCC
AlrAct         = AlrAct.split("_")
AlrId          = int(AlrAct[0])
AlrStado       = int(AlrAct[1]) # 1 = Activada, 2 = Desactivada, 3 = Reconocida

# Configuracion de avisos por telegram

TOKEN_BOT      = "5010499917:AAFd05Y2PLe4IitbvheM-DebdNVbJOJ3pkk"
CHAT_ID        = "-1001738340790%20"
MENSAJE_ALARMA = ""

TxtAlr, HabEnvio = ObtenerAlr(AlrId)

# Si el envío de alarmas no está habilitado salgo
if HabEnvio == False:
    sys.exit()

if AlrStado == 1:
    MENSAJE_ALARMA = TxtAlr + " activada"
if AlrStado == 2:
    MENSAJE_ALARMA = TxtAlr + " desactivada"

if MENSAJE_ALARMA != "":

    # Enviar mensaje y guardar respuesta de curl.
    rsp = subprocess.Popen(f'curl -d "text={MENSAJE_ALARMA}" -X POST https://api.telegram.org/bot{TOKEN_BOT}/sendMessage?chat_id={CHAT_ID}', stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    # Intento parsear la respuesta, si no puedo es porque no hay internet y la respuesta no cuadra.
    try:
         
         stdout = json.load(rsp.stdout)

    except json.JSONDecodeError: # Si no puedo decodificar guarda en el log la fecha y hora e indico que no hay internet

        log = open("log.txt", "a")
        log.write(datetime.utcfromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S') + ": curl: (6) Could not resolve host: api.telegram.org\n")
        log.close()
        sys.exit(1)

    ok = (stdout["ok"]) # Comprobar que el mensaja ha sido enviado
    
    #Si el mensaje no se ha enviado (por cualquier motivo a excepcion del cooldown de Telegram) escribimos en log.txt la respuesta de curl y salimos del script con codigo de respuesta 1 (error)
    if not ok:
        print("El mensaje no se ha enviado")
        codigo_error = int(stdout["error_code"]) # Obtener codigo de error
        
        # Si el error no viene del cooldown guardo en el registro el error.
        if codigo_error != 429:
            log = open("log.txt", "a")
            log.write(datetime.utcfromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S') + ": "+str(stdout)+"\n")
            log.close()
        sys.exit(1)
    

time.sleep(0.75)

