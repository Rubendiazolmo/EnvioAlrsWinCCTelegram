import tkinter as tk
from tkinter import ttk
import pyodbc
import sys
from threading import Thread

# Función para obterner la base de datos principal de WinCC
def ObtenerBBDD():

    # Define la cadena de conexión a la base de datos principal para obtener la bbdd principal
    conn_str = (
        r"Driver={SQL Server};"
        r"Server=DESKTOP-KFESO7O\WINCC;"
        r"Database=master;"
        r"Trusted_Connection=yes;"
    )

    # Crea una conexión a la base de datos
    conn = pyodbc.connect(conn_str)

    # Crea un objeto cursor
    cursor = conn.cursor()

    # Ejecuta una consulta SQL
    cursor.execute('SELECT * FROM dbo.CAConfig')

    # Obtiene los resultados de la consulta
    ResultTxtLib = cursor.fetchall()

    # Nombre base de datos
    nombre_bbdd = ""

    # Imprime los resultados en la consola
    for _, db_name, _ in ResultTxtLib:
        nombre_bbdd = db_name[:-1] # Le quito la "R" del final del nombre de la BBDD

    # Cierra la conexión a la base de datos
    conn.close()

    if nombre_bbdd == "":
        print("No se ha podido obtener la base de datos del proyecto")
        sys.exit()
    return nombre_bbdd

# Cosultar base de datos de las alarmas
def ListarArls(Filtro):
    
    output = list()

    nombre_bbdd = ObtenerBBDD()

    # Define la cadena de conexión a la base de datos del proyecto
    conn_str = (
        r"Driver={SQL Server};"
        r"Server=DESKTOP-KFESO7O\WINCC;"
        f"Database={nombre_bbdd};"
        r"Trusted_Connection=yes;"
    )

    # Crea una conexión a la base de datos
    conn = pyodbc.connect(conn_str)

    # Crea un objeto cursor
    cursor = conn.cursor()

    # Definir la consula SQL
    SQLQuery = r""
    SQLQuery += r"SELECT dbo.TXTTable.L1034 AS L1034_TB1, dbo.MSMsgs.NR, dbo.MSMsgs.EnviarAlarma "
    SQLQuery += r"FROM dbo.MSMsgs "
    SQLQuery += r"JOIN dbo.TXTTable ON dbo.MSMsgs.TB1 = dbo.TXTTable.TEXTID "
    # Si hay algún filtro definido lo uso
    if Filtro != "":
        SQLQuery += f"WHERE dbo.TXTTable.L1034 LIKE '%{Filtro}%' "
    SQLQuery += r"ORDER BY dbo.MSMsgs.NR"

    # Ejecuta una consulta SQL para obtener tabla del text library
    cursor.execute(SQLQuery)

    # Obtiene los resultados de la consulta
    RspQuery = cursor.fetchall()

    # Cierra la conexión a la base de datos
    conn.close()

    for alarma in RspQuery:

        AlrTxt, AlrNr, HabEnvia = alarma
        
        output.append([AlrTxt, HabEnvia, AlrNr])

    return output

# Alternar casilla "Activar una acción" de la alarma indicada en AlrNr
def CambiarHab(AlrNr):

    global TxtAlrs, HabsAlrs, IdsAlrs

    NombreBBDD = ObtenerBBDD()

    # Define la cadena de conexión a la base de datos del proyecto
    ConnStr = (
        r"Driver={SQL Server};"
        r"Server=DESKTOP-KFESO7O\WINCC;"
        f"Database={NombreBBDD};"
        r"Trusted_Connection=yes;"
    )

    # Crea una conexión a la base de datos
    Conn = pyodbc.connect(ConnStr)

    # Crea un objeto cursor
    Cursor = Conn.cursor()

    SQLQuery = ""
    SQLQuery += "UPDATE dbo.MSMsgs "
    SQLQuery += f"SET EnviarAlarma = CASE WHEN EnviarAlarma IS NULL OR EnviarAlarma = 0 THEN 1 ELSE 0 END "
    SQLQuery += f"WHERE NR = {AlrNr}"

    print(SQLQuery)

    # Ejecuta una consulta SQL para obtener tabla del text library
    Cursor.execute(SQLQuery)

    Cursor.commit()

    # Cierra la conexión a la base de datos
    Conn.close()

# Alternar casilla "Activar una acción" de la alarma seleccionada
def CambiarArl(event):

    global TxtAlrs, HabsAlrs, IdsAlrs

    TxtAlrSel = TxtAlrsList.curselection()

    AlrNr = (IdsAlrs[TxtAlrSel[0]])
    
    CambiarHab(AlrNr)

    ActualizarListBox()

# Rellenar ListBox de las alarma
def ActualizarListBox():

    # Actualizar listbox
    global FiltroAlr, TxtAlrsList
    global TxtAlrs, HabsAlrs, IdsAlrs

    scroll_position = TxtAlrsList.yview()[0]  # Obtener la posición de desplazamiento

    Alarmas = ListarArls(FiltroAlr)

    if len(Alarmas) == 0:
        TxtAlrsList.delete(0, tk.END)
        TxtAlrsList.insert(0, ("No se han encontrado resultados..."))

        # Esto se ejecuta cada vez que se modifica la alarma a buscar, si ya no hay nada bindeado da fallo
        try:
            # Deshabilito doble click en los elementos
            TxtAlrsList.unbind('<Double-1>', CambiarArl)
        except:
            pass
        return

    TxtAlrs = list(zip(*Alarmas))[0]
    HabsAlrs = list(zip(*Alarmas))[1]
    IdsAlrs = list(zip(*Alarmas))[2]

    AlsAMostar = list()

    FiltroAlrAux = FiltroAlr

    if FiltroAlr == "Introduce la alarma buscada...":
        FiltroAlrAux = ""

    for TxtAlr, HabAlr, IdAlr in ListarArls(FiltroAlrAux):

        if TxtAlr[0] == "@":
            continue

        EstadoAlr = "Deshabilitada"

        if HabAlr:
            EstadoAlr = "Habilitada"

        AlsAMostar.append(f'{TxtAlr} - {EstadoAlr} {9999*" "}') # Añado 9999 espacios para poder hacer click en cualquier parte del listbox

    # Borro listbox y lo vuelvo a rellenar con las nuevas alarmas
    TxtAlrsList.delete(0, tk.END)
    TxtAlrsList.insert(0, *AlsAMostar)

    # Bindear doble click para cambiar hab de envio de alarma
    TxtAlrsList.bind('<Double-1>', CambiarArl)

    TxtAlrsList.yview_moveto(scroll_position)  # Aplicar la misma posición de desplazamiento

# Habilitar todas las alarmas que cumplen con el filtro
def HabilitarTodas():

    global IdsAlrs

    def ModificarAlarmas():

        for id, hab in zip(IdsAlrs, HabsAlrs):

            if hab == False:
                CambiarHab(id)

        progressbar.destroy()
        ActualizarListBox()


    # Variable que controla el progreso de la barra.
    progressbar = ttk.Progressbar(orient=tk.HORIZONTAL, length=160, maximum=len(IdsAlrs), mode="indeterminate")
    progressbar.place(x=PosXProgressBar, y=PosYProgressBar, width=AnchoProgressBar, height=AltoProgressBar)
    progressbar.start(interval=1)
    Thread(target=ModificarAlarmas).start()

# Deshabilitar todas las alarmas que cumplen con el filtro
def DeshabilitarTodas():

    global IdsAlrs

    def ModificarAlarmas():

        for id, hab in zip(IdsAlrs, HabsAlrs):

            if hab == True:
                CambiarHab(id)

        progressbar.destroy()
        ActualizarListBox()


    # Variable que controla el progreso de la barra.
    progressbar = ttk.Progressbar(orient=tk.HORIZONTAL, length=160, maximum=len(IdsAlrs), mode="indeterminate")
    progressbar.place(x=PosXProgressBar, y=PosYProgressBar, width=AnchoProgressBar, height=AltoProgressBar)
    progressbar.start(interval=1)
    Thread(target=ModificarAlarmas).start()

# Reset filtro
FiltroAlr = ""


# Posiociones de los widgets
# ********************************************************************************************

AnchoVentana = 900
AltoVentana = 600
PaddingX = PaddingY = 10

AnchoBotones = 90
AltoBotones = AltoCampoBuscar = 25

PosXBotonDesHabTodo = AnchoVentana - AnchoBotones - PaddingX
PosYBotonDesHabTodo = PaddingY

PosXBotonHabTodo = AnchoVentana - AnchoBotones*2 - PaddingX*2
PosYBotonHabTodo = PaddingY

AnchoCampoBuscar = AnchoVentana - PaddingX*2 - (AnchoVentana - PosXBotonHabTodo)

PosYListaAlr = PaddingY + AltoCampoBuscar + PaddingY
PosXListaAlr = PaddingX
AnchoListaAlr = AnchoVentana - (PaddingX*2)
AltoListaAlr = AltoVentana - PaddingY*3 - AltoCampoBuscar

PosXProgressBar = 30
AnchoProgressBar = AnchoVentana - PosXProgressBar*2

AltoProgressBar = 30
PosYProgressBar = AltoVentana / 2 - AltoProgressBar / 2

# ********************************************************************************************


ventana = tk.Tk()
ventana.geometry(f'{AnchoVentana}x{AltoVentana}')
ventana.title("Configurar envio alarmas ")
ventana.resizable(width=False, height=False)  # Bloquear redimensionamiento y maximización

# Fitro de alarmas (fusilado de Chat-GPT)--------------------------------------

# Función para obtener el valor del campo de entrada y guardarlo en FiltroAlr
def FiltrarAlarmas(*args):

    global FiltroAlr
    FiltroAlr = AlrBuscada.get()

    CampoBucarAlr.config(fg="Black")

    if FiltroAlr == "Introduce la alarma buscada...":
        CampoBucarAlr.config(fg="Grey")
        return

    ActualizarListBox()

# Crear una variable de control para el campo de entrada
AlrBuscada = tk.StringVar()

# Asociar la variable de control al campo de entrada
CampoBucarAlr = tk.Entry(ventana, textvariable=AlrBuscada, fg="grey")
CampoBucarAlr.place(x=PaddingX, y=PosYBotonDesHabTodo, width=AnchoCampoBuscar, height=AltoCampoBuscar)
CampoBucarAlr.insert(0, "Introduce la alarma buscada...")

BotonHabTodas = ttk.Button(text="Hab. todo", command=HabilitarTodas)
BotonHabTodas.place(x=PosXBotonHabTodo, y=PosYBotonHabTodo, width=AnchoBotones, height=AltoBotones)

BotonDeshabTodas = ttk.Button(text="Deshab. todo", command=DeshabilitarTodas)
BotonDeshabTodas.place(x=PosXBotonDesHabTodo, y=10, width=AnchoBotones, height=AltoBotones)

# Registrar la función on_cambio para ejecutarse cada vez que la variable de control cambie
AlrBuscada.trace("w", FiltrarAlarmas)
# ------------------------------------------------------------------------------

# Crear lista de alarmas
TxtAlrsList = tk.Listbox(ventana)
TxtAlrsList.place(x=PosXListaAlr, y=PosYListaAlr, width=AnchoListaAlr, height=AltoListaAlr)

ActualizarListBox()

CampoBucarAlr.bind("<FocusIn>", lambda event: CampoBucarAlr.delete(0,"end") if AlrBuscada.get() == "Introduce la alarma buscada..." else None)
CampoBucarAlr.bind("<FocusOut>", lambda event: CampoBucarAlr.insert(0, "Introduce la alarma buscada...") if AlrBuscada.get() == "" else None)


ventana.mainloop()
