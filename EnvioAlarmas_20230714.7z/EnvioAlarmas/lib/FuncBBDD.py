import pyodbc
import sys
import pandas as pd
import os

def ObtenerBBDD():

    # Define la cadena de conexión a la base de datos principal para obtener la bbdd principal
    conn_str = (
        r"Driver={SQL Server};"
        f"Server={os.getenv('COMPUTERNAME')}\WINCC;"
        r"Database=master;"
        r"Trusted_Connection=yes;"
    )

    # Crea una conexión a la base de datos
    conn = pyodbc.connect(conn_str)

    # Crea un objeto cursor
    cursor = conn.cursor()

    # Ejecuta una consulta SQL
    cursor.execute('SELECT * FROM dbo.CAConfig')

    # Obtiene los resultados de la consulta
    ResultTxtLib = cursor.fetchall()

    # Nombre base de datos
    nombre_bbdd = ""

    # Imprime los resultados en la consola
    for _, db_name, _ in ResultTxtLib:
        nombre_bbdd = db_name[:-1] # Le quito la "R" del final del nombre de la BBDD

    # Cierra la conexión a la base de datos
    conn.close()

    if nombre_bbdd == "":
        print("No se ha podido obtener la base de datos del proyecto")
        sys.exit()
    return nombre_bbdd

def ObtenerAlr(AlarmaAEnviar):
    
    nombre_bbdd = ObtenerBBDD()

    # Define la cadena de conexión a la base de datos del proyecto
    conn_str = (
        r"Driver={SQL Server};"
        f"Server={os.getenv('COMPUTERNAME')}\WINCC;"
        f"Database={nombre_bbdd};"
        r"Trusted_Connection=yes;"
    )

    # Crea una conexión a la base de datos
    conn = pyodbc.connect(conn_str)

    # Crea un objeto cursor
    cursor = conn.cursor()

    # Definir la consula SQL
    SQLQuery = r""
    SQLQuery += r"SELECT dbo.TXTTable.L1034 AS L1034_TB1, dbo.MSMsgs.Priority "
    SQLQuery += r"FROM dbo.MSMsgs "
    SQLQuery += r"JOIN dbo.TXTTable ON dbo.MSMsgs.TB1 = dbo.TXTTable.TEXTID "
    SQLQuery += f"WHERE dbo.MSMsgs.NR = {AlarmaAEnviar}"

    # Ejecuta una consulta SQL para obtener tabla del text library
    cursor.execute(SQLQuery)

    # Obtiene los resultados de la consulta
    RspQuery = cursor.fetchall()

    # Cierra la conexión a la base de datos
    conn.close()

    AlrTxt, AlrPrio = RspQuery[0]
    
    return(AlrTxt, AlrPrio)

# Cosultar base de datos de las alarmas
def ListarArls(Filtro, Prio):
    
    output = list()

    nombre_bbdd = ObtenerBBDD()

    # Define la cadena de conexión a la base de datos del proyecto
    conn_str = (
        r"Driver={SQL Server};"
        f"Server={os.getenv('COMPUTERNAME')}\WINCC;"
        f"Database={nombre_bbdd};"
        r"Trusted_Connection=yes;"
    )

    # Crea una conexión a la base de datos
    conn = pyodbc.connect(conn_str)

    # Crea un objeto cursor
    cursor = conn.cursor()

    # Definir la consula SQL
    SQLQuery = r""
    SQLQuery += r"SELECT dbo.TXTTable.L1034 AS L1034_TB1, dbo.MSMsgs.NR, dbo.MSMsgs.Priority "
    SQLQuery += r"FROM dbo.MSMsgs "
    SQLQuery += r"JOIN dbo.TXTTable ON dbo.MSMsgs.TB1 = dbo.TXTTable.TEXTID "
    
    # Si Prio vale 11 quiero mostar todas las alarmas configuradas
    if Prio < 11:
        SQLQuery += f"WHERE dbo.MSMsgs.Priority = {Prio} "
    else:
        SQLQuery += f"WHERE dbo.MSMsgs.Priority > 0 "
    # Si hay algún filtro definido lo uso
    if Filtro != "":
        SQLQuery += f"AND dbo.TXTTable.L1034 LIKE '%{Filtro}%' "
    SQLQuery += r"ORDER BY dbo.MSMsgs.NR"

    # Ejecuta una consulta SQL para obtener tabla del text library
    cursor.execute(SQLQuery)

    # Obtiene los resultados de la consulta
    RspQuery = cursor.fetchall()

    # Cierra la conexión a la base de datos
    conn.close()

    for alarma in RspQuery:

        AlrTxt, AlrNr, HabEnvia = alarma
        
        output.append([AlrTxt, HabEnvia, AlrNr])

    return output