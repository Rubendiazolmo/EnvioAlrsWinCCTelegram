import sys
import time
import subprocess
import json
from lib.FuncBBDD import ObtenerAlr
from datetime import datetime
import sqlite3

Ruta = "C:/EnvioAlarmas"

# Conectar a la base de datos
conexion = sqlite3.connect(f'{Ruta}/LogDB/RegFallos.db')
cursor = conexion.cursor()

# Configuracion de lectura de alarmas
AlrAct         = sys.argv[1].replace("./Alrs/","") # Alarma activada, estructura pszMsgData de WinCC
AlrAct         = AlrAct.split("_")
AlrId          = int(AlrAct[0])
AlrStado       = int(AlrAct[1]) # 1 = Activada, 2 = Desactivada 
AlrHoraEvento  = sys.argv[2].replace("_"," ") # Obtengo fecha y hora que saltó la alarma

# Configuracion de avisos por telegram
TOKEN_BOT      = "5010499917:AAFd05Y2PLe4IitbvheM-DebdNVbJOJ3pkk"
CHAT_ID        = ["Mete aqui los ChatsIds de los grupos",
                  "-1001738340790%20",
                  "-1001930221961", 
                  "Grupo 3",
                  "Grupo 4",
                  "Grupo 5",
                  "Grupo 6",
                  "Grupo 7",
                  "Grupo 8",
                  "Grupo 9",
                  "Grupo 10"]
MENSAJE_ALARMA = ""

TxtAlr, PrioAlr = ObtenerAlr(AlrId)

# Si el envío de alarmas no está habilitado salgo
if PrioAlr == 0:
    sys.exit()

if AlrStado == 1:
    MENSAJE_ALARMA = f'{AlrHoraEvento} ALARMA ACTIVA: {TxtAlr}'
if AlrStado == 2:
    MENSAJE_ALARMA = f'{AlrHoraEvento} ALARMA DESACTIVADA: {TxtAlr}'

if MENSAJE_ALARMA != "":

    # Enviar mensaje y guardar respuesta de curl.
    rsp = subprocess.Popen(f'curl -d "text={MENSAJE_ALARMA}" -X POST https://api.telegram.org/bot{TOKEN_BOT}/sendMessage?chat_id={CHAT_ID[PrioAlr]}', stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    # Intento parsear la respuesta, si no puedo es porque no hay internet y la respuesta no cuadra.
    try:
         
        stdout = json.load(rsp.stdout)

    except json.JSONDecodeError: # Si no puedo decodificar guarda en el log la fecha y hora e indico que no hay internet

        # Insertar un registro en la tabla con el campo 'id' autoincremental
        datos = (MENSAJE_ALARMA, datetime.utcfromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S') + ": " + ": curl: (6) Could not resolve host: api.telegram.org")
        cursor.execute("INSERT INTO Fallos (TxtAlr, Error) VALUES (?, ?)", datos)

        # Guardar los cambios y cerrar la conexión
        conexion.commit()
        conexion.close()
        sys.exit(1)

    ok = (stdout["ok"]) # Comprobar que el mensaja ha sido enviado
    
    #Si el mensaje no se ha enviado (por cualquier motivo a excepcion del cooldown de Telegram) escribimos en log.txt la respuesta de curl y salimos del script con codigo de respuesta 1 (error)
    if not ok:
        print("El mensaje no se ha enviado")
        codigo_error = int(stdout["error_code"]) # Obtener codigo de error
        
        # Si el error no viene del cooldown guardo en el registro el error.
        if codigo_error != 429:
            # Insertar un registro en la tabla con el campo 'id' autoincremental
            datos = (MENSAJE_ALARMA, datetime.utcfromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S') + ": " + str(stdout))
            cursor.execute("INSERT INTO Fallos (TxtAlr, Error) VALUES (?, ?)", datos)

            # Guardar los cambios y cerrar la conexión
            conexion.commit()
            conexion.close()
        sys.exit(1)
    

time.sleep(0.75)

