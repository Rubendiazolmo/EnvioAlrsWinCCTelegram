import sqlite3

# Conectar a la base de datos
conexion = sqlite3.connect('LogDB/RegFallos.db')
cursor = conexion.cursor()

# Insertar un registro en la tabla con el campo 'id' autoincremental
datos = ("h0ola", "Adios")
cursor.execute("INSERT INTO Fallos (TxtAlr, Error) VALUES (?, ?)", datos)

# Guardar los cambios y cerrar la conexión
conexion.commit()
conexion.close()