import pandas as pd
import numpy as np
import sys
import os
import string
import time
import subprocess

DETACHED_PROCESS = 0x00000008

PATH = "C:/Python/"

# Configuración de lectura de alarmas

COLUMNA_TEXTOS = "N" #Columna en la que está el texto que queremos enviar
INDEX_TEXTO    = string.ascii_lowercase.index(COLUMNA_TEXTOS.lower())
AlrAct         = sys.argv[1] # Alarma activada, estructura pszMsgData de WinCC
AlrAct         = AlrAct.split(",")
AlrId          = int(AlrAct[0])
AlrStado       = int(AlrAct[1]) # 1 = Activada, 2 = Desactivada, 3 = Reconocida

# Configuración de avisos por telegram

TOKEN_BOT      = "5010499917:AAFd05Y2PLe4IitbvheM-DebdNVbJOJ3pkk"
CHAT_ID        = "-1001738340790%20"
MENSAJE_ALARMA = ""

# Lectura de alarmas desde Excel exportado

Alrs = np.array(pd.read_excel(PATH + 'Export.xlsx', sheet_name="Avisos"))[2:] #Extaigo los textos de las alarmas del Excel exportado en Wincc. Quito las 3 primeras filas del Excel para que sea más cómodo recorrer la matriz con un for.
Alrs = pd.DataFrame(Alrs)

for i, Alr in enumerate(Alrs[0]):
    
    if (Alr == (AlrId)) and (AlrStado == 1):
        MENSAJE_ALARMA = (str(Alrs[INDEX_TEXTO][i]) + " activada")
    if (Alr == (AlrId)) and (AlrStado == 2):
        MENSAJE_ALARMA = (str(Alrs[INDEX_TEXTO][i]) + " desactivada")

if MENSAJE_ALARMA != "":

    subprocess.call(f'curl -d "text={MENSAJE_ALARMA}" -X POST https://api.telegram.org/bot{TOKEN_BOT}/sendMessage?chat_id={CHAT_ID}', creationflags=DETACHED_PROCESS)

time.sleep(0.25)

