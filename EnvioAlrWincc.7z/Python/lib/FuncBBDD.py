import pyodbc
import sys
import pandas as pd

def ObtenerBBDD():

    # Define la cadena de conexión a la base de datos principal para obtener la bbdd principal
    conn_str = (
        r"Driver={SQL Server};"
        r"Server=DESKTOP-KFESO7O\WINCC;"
        r"Database=master;"
        r"Trusted_Connection=yes;"
    )

    # Crea una conexión a la base de datos
    conn = pyodbc.connect(conn_str)

    # Crea un objeto cursor
    cursor = conn.cursor()

    # Ejecuta una consulta SQL
    cursor.execute('SELECT * FROM dbo.CAConfig')

    # Obtiene los resultados de la consulta
    ResultTxtLib = cursor.fetchall()

    # Nombre base de datos
    nombre_bbdd = ""

    # Imprime los resultados en la consola
    for _, db_name, _ in ResultTxtLib:
        nombre_bbdd = db_name[:-1] # Le quito la "R" del final del nombre de la BBDD

    # Cierra la conexión a la base de datos
    conn.close()

    if nombre_bbdd == "":
        print("No se ha podido obtener la base de datos del proyecto")
        sys.exit()
    return nombre_bbdd

def ObtenerTxtAlr(AlarmaAEnviar):

    nombre_bbdd = ObtenerBBDD()

    AlrID_TxtAlr = list()

    # Define la cadena de conexión a la base de datos del proyecto
    conn_str = (
        r"Driver={SQL Server};"
        r"Server=DESKTOP-KFESO7O\WINCC;"
        f"Database={nombre_bbdd};"
        r"Trusted_Connection=yes;"
    )

    # Crea una conexión a la base de datos
    conn = pyodbc.connect(conn_str)

    # Crea un objeto cursor
    cursor = conn.cursor()

    # Ejecuta una consulta SQL para obtener tabla del text library
    cursor.execute('SELECT * FROM dbo.TXTTable')

    # Obtiene los resultados de la consulta
    ResultTxtLib = cursor.fetchall()

    # Ejecuta una consulta SQL para obtener tabla con id de la alarma e id del texto de la alarma
    cursor.execute('SELECT * FROM dbo.MSMsgs')

    # Obtiene los resultados de la consulta
    ResultAlarms = cursor.fetchall()

    # Cierra la conexión a la base de datos
    conn.close()

    # Tranformo el tipo de datos los hijos de la lista "ResultTxtLib" a lista
    for i, result in enumerate(ResultTxtLib):
        ResultTxtLib[i] = list(result)

    # Creo un dataframe del TxtLibrary
    TxtLibraryDf = pd.DataFrame(ResultTxtLib)
    TxtLibraryDf.columns = ["TxtId", "Ingles", "Español", "_", "_"] # Añado cabecera al df

    for i in ResultAlarms:
        TxtAlr = TxtLibraryDf.loc[TxtLibraryDf['TxtId'] == i[5], 'Español'].iloc[0] # Obtengo el Texto de la alarma
        AlrID_TxtAlr.append([i[0],TxtAlr]) # Añado en la lista el Id de la alarma y el Texto de la alarma


    # Creo un dataframe donde asigno el ID de la alrma con el texto de la alarma
    TxtsAlrsDf = pd.DataFrame(AlrID_TxtAlr)
    TxtsAlrsDf.columns = (["AlrID", "TxtAlr"]) # Añado cabecera al df

    return (TxtsAlrsDf.loc[TxtsAlrsDf['AlrID'] == AlarmaAEnviar, 'TxtAlr'].iloc[0])
